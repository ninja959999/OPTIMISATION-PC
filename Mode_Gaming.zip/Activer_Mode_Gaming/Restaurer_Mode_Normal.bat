@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0game_perf_mode.ps1" -Restore
