# ============================================
# game_perf_mode.ps1
# BY NINJA GAMING
# Bascule le PC en mode "Performance Gaming" avant de lancer Valorant
# Usage:
#   .\game_perf_mode.ps1          -> active le mode perf
#   .\game_perf_mode.ps1 -Restore -> revient en mode normal
# ============================================

param(
    [switch]$Restore
)

# Apps a fermer avant de jouer (modifie cette liste selon tes besoins)
$AppsToClose = @("Steam", "OneDrive", "Teams", "Slack", "chrome", "opera", "EpicGamesLauncher", "GalaxyClient", "XboxApp", "GamingApp")

# Nom du processus principal de Valorant (le jeu, pas le launcher)
$ValorantProcessName = "VALORANT-Win64-Shipping"

# GUIDs des plans d'alimentation Windows par defaut
$PlanEquilibre    = "381b4222-f694-41f0-9685-ff5bb260df2e"
$PlanPerformances = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"

function Show-Banner {
    Write-Host "=============================================" -ForegroundColor Cyan
    Write-Host "   OPTIMISATION VALORANT - BY NINJA GAMING" -ForegroundColor Cyan
    Write-Host "=============================================" -ForegroundColor Cyan
    Write-Host ""
}

Show-Banner

if ($Restore) {
    Write-Host "=== Restauration du mode normal ===" -ForegroundColor Yellow
    try {
        powercfg /s $PlanEquilibre
        Write-Host "  Plan d'alimentation restaure (Equilibre)"
    } catch {
        Write-Host "  [SKIP] Plan d'alimentation -> $($_.Exception.Message)" -ForegroundColor Red
    }
    Write-Host ""
    Write-Host "Relance tes apps manuellement si besoin (Discord, Spotify, etc.)."
    Read-Host "`nAppuie sur Entree pour fermer"
    exit
}

$reponse = Read-Host "Veux-tu activer le mode Performance maintenant ? (oui/non)"
if ($reponse -notin @("oui", "o", "y", "yes")) {
    Write-Host "`nOk, rien n'a ete fait."
    Read-Host "`nAppuie sur Entree pour fermer"
    exit
}

Write-Host ""
Write-Host "=== Activation du mode Performance ===" -ForegroundColor Green

# 1. Fermer les apps gourmandes en arriere-plan
foreach ($app in $AppsToClose) {
    try {
        $proc = Get-Process -Name $app -ErrorAction SilentlyContinue
        if ($proc) {
            Stop-Process -Name $app -Force -ErrorAction Stop
            Write-Host "  Ferme: $app"
        }
    } catch {
        Write-Host "  [SKIP] $app -> $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

# 2. Passer sur le plan d'alimentation "Performances elevees"
try {
    powercfg /s $PlanPerformances
    Write-Host "  Plan d'alimentation -> Performances elevees"
} catch {
    Write-Host "  [SKIP] Plan d'alimentation -> $($_.Exception.Message)" -ForegroundColor Yellow
}

# 3. Vider le cache DNS
try {
    ipconfig /flushdns | Out-Null
    Write-Host "  Cache DNS vide"
} catch {
    Write-Host "  [SKIP] Cache DNS -> $($_.Exception.Message)" -ForegroundColor Yellow
}

# 4. Petit nettoyage memoire
try {
    [System.GC]::Collect()
} catch {}

Write-Host ""
Write-Host "=== Pret a lancer Valorant ! ===" -ForegroundColor Green
Write-Host ""

# 5. Attendre le lancement de Valorant pour booster sa priorite automatiquement
Write-Host "Lance Valorant maintenant -> j'attends qu'il demarre pour booster sa priorite." -ForegroundColor Cyan
Write-Host "(90 secondes max, Ctrl+C pour annuler cette etape si tu veux pas attendre)"
Write-Host ""

$valorantProcess = $null
$timeout = 90
$elapsed = 0

while ($elapsed -lt $timeout) {
    try {
        $valorantProcess = Get-Process -Name $ValorantProcessName -ErrorAction SilentlyContinue
    } catch {
        $valorantProcess = $null
    }
    if ($valorantProcess) { break }
    Start-Sleep -Seconds 2
    $elapsed += 2
}

if ($valorantProcess) {
    try {
        $valorantProcess.PriorityClass = "High"
        Write-Host "  Valorant detecte -> priorite mise sur Haute" -ForegroundColor Green
    } catch {
        Write-Host "  [SKIP] Changement de priorite impossible -> $($_.Exception.Message)" -ForegroundColor Yellow
        Write-Host "  (Vanguard a peut-etre bloque l'action, le jeu tournera quand meme normalement)"
    }
} else {
    Write-Host "  Valorant pas detecte apres $timeout secondes, etape ignoree." -ForegroundColor Yellow
    Write-Host "  Rien de grave, le reste des optimisations est deja applique."
}

Write-Host ""
Write-Host "Pour revenir a la normale apres ta session: .\game_perf_mode.ps1 -Restore"
Read-Host "`nAppuie sur Entree pour fermer"