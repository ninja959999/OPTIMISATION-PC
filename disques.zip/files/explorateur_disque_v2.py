"""
Explorateur Disque Graphique v2
- Scan avec barre de progression visuelle
- Classification automatique (Système / Programme / Perso / Média / Jeu...)
- Alerte si un dossier est important pour Windows (à ne pas supprimer)
- Ouvrir dans l'explorateur, Supprimer, Naviguer
"""

import os
import sys
import threading
import subprocess
import shutil
import tkinter as tk
from tkinter import ttk, filedialog, messagebox


# ---------- Classification ----------

DOSSIERS_CRITIQUES = {
    "windows", "program files", "program files (x86)", "programdata",
    "system32", "$recycle.bin", "recovery", "boot", "efi", "system volume information",
    "appdata", "drivers", "winsxs",
}

EXT_MEDIA = {".mp4", ".mkv", ".avi", ".mov", ".mp3", ".wav", ".flac", ".png", ".jpg",
             ".jpeg", ".gif", ".webp", ".psd", ".ai"}
EXT_DOC = {".pdf", ".docx", ".doc", ".txt", ".xlsx", ".pptx", ".csv", ".md"}
EXT_ARCHIVE = {".zip", ".rar", ".7z", ".tar", ".gz", ".iso"}
EXT_CODE = {".py", ".js", ".ts", ".html", ".css", ".cpp", ".cs", ".java", ".json", ".gd", ".tscn"}
EXT_EXECUTABLE = {".exe", ".msi", ".dll", ".sys", ".bat"}

DOSSIERS_JEUX = {"steamlibrary", "steam", "epic games", "games", "gog games", "riot games"}

DOSSIERS_CACHE = {"dxcache", "glcache", "shadercache", "cache", "temp", "tmp", "logs",
                   "crashdumps", "gpucache", "httpcache"}


def classifier(nom, chemin, est_dossier):
    nom_l = nom.lower()
    if est_dossier:
        if nom_l in DOSSIERS_CACHE:
            return ("🧹 Cache — safe à vider", "#00d4ff", False)
        if nom_l in DOSSIERS_CRITIQUES:
            return ("⚠️ Système Windows", "#ff5555", True)
        if nom_l in DOSSIERS_JEUX or "steamapps" in chemin.lower():
            return ("🎮 Jeux", "#57c785", False)
        if "program files" in chemin.lower():
            return ("⚙️ Programme", "#e0a44e", True)
        return ("📁 Dossier perso", "#5aa9e6", False)
    else:
        ext = os.path.splitext(nom_l)[1]
        if ext in EXT_EXECUTABLE:
            return ("⚙️ Système/Exécutable", "#e0a44e", True)
        if ext in EXT_MEDIA:
            return ("🎬 Média", "#c77dff", False)
        if ext in EXT_DOC:
            return ("📄 Document", "#5aa9e6", False)
        if ext in EXT_ARCHIVE:
            return ("🗜️ Archive", "#f4a261", False)
        if ext in EXT_CODE:
            return ("💻 Code", "#57c785", False)
        return ("📦 Autre", "#999999", False)


def est_chemin_sensible(chemin):
    parties = chemin.lower().replace("/", "\\").split("\\")
    return any(p in DOSSIERS_CRITIQUES for p in parties)


def taille_lisible(o):
    for unite in ['o', 'Ko', 'Mo', 'Go', 'To']:
        if o < 1024:
            return f"{o:.2f} {unite}"
        o /= 1024
    return f"{o:.2f} Po"


def taille_dossier(chemin):
    total = 0
    try:
        for entry in os.scandir(chemin):
            try:
                if entry.is_file(follow_symlinks=False):
                    total += entry.stat().st_size
                elif entry.is_dir(follow_symlinks=False):
                    total += taille_dossier(entry.path)
            except (PermissionError, OSError):
                continue
    except (PermissionError, OSError):
        pass
    return total


# ---------- Application ----------

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Explorateur Disque — by Ninja Gaming")
        self.geometry("1050x680")
        self.configure(bg="#181818")
        try:
            self.attributes("-alpha", 0.98)
        except tk.TclError:
            pass

        self.historique = []
        self.chemin_actuel = tk.StringVar()
        self.donnees = []
        self.scan_en_cours = False

        self._style()
        self._construire_ui()
        self._splash()

    def _splash(self):
        overlay = tk.Frame(self, bg="#0d0d0d")
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        tk.Label(overlay, text="⚡", bg="#0d0d0d", fg="#00d4ff",
                 font=("Segoe UI", 40)).pack(pady=(220, 0))
        tk.Label(overlay, text="Explorateur Disque", bg="#0d0d0d", fg="white",
                 font=("Segoe UI", 20, "bold")).pack(pady=(10, 2))
        tk.Label(overlay, text="by Ninja Gaming", bg="#0d0d0d", fg="#00d4ff",
                 font=("Segoe UI", 11, "italic")).pack()
        self.after(1000, overlay.destroy)

    def _style(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Treeview", background="#242424", fieldbackground="#242424",
                         foreground="#e8e8e8", rowheight=28, font=("Segoe UI", 10),
                         borderwidth=0)
        style.configure("Treeview.Heading", background="#2f2f2f", foreground="#00d4ff",
                         font=("Segoe UI Semibold", 10), relief="flat")
        style.map("Treeview", background=[("selected", "#0a84ff")])
        style.configure("TProgressbar", troughcolor="#242424", background="#00d4ff",
                         thickness=6, borderwidth=0)
        self.tree_tags_pairs = ("#242424", "#282828")  # lignes alternées

    def _construire_ui(self):
        # ----- barre du haut -----
        top = tk.Frame(self, bg="#181818")
        top.pack(fill="x", padx=12, pady=(10, 6))

        def bouton(parent, texte, cmd, couleur="#2f2f2f"):
            b = tk.Button(parent, text=texte, command=cmd, bg=couleur, fg="white",
                           relief="flat", padx=12, pady=6, font=("Segoe UI", 9, "bold"),
                           activebackground="#0a84ff", cursor="hand2")
            return b

        bouton(top, "📂 Choisir dossier", self.choisir_dossier, "#0a84ff").pack(side="left")
        bouton(top, "⬅ Précédent", self.precedent).pack(side="left", padx=6)
        bouton(top, "🔄 Rescanner", lambda: self.scanner(self.chemin_actuel.get())).pack(side="left")
        bouton(top, "🗂️ Ouvrir ce dossier", self.ouvrir_chemin_actuel, "#3a3a3a").pack(side="left", padx=6)

        tk.Label(top, text="⚡ by Ninja Gaming", bg="#181818", fg="#444444",
                 font=("Segoe UI", 8, "italic")).pack(side="right", padx=4)

        # ----- fil d'ariane -----
        chemin_frame = tk.Frame(self, bg="#181818")
        chemin_frame.pack(fill="x", padx=12)
        tk.Label(chemin_frame, textvariable=self.chemin_actuel, bg="#181818",
                 fg="#00d4ff", anchor="w", font=("Consolas", 9)).pack(side="left", fill="x", expand=True)

        # ----- recherche -----
        search_frame = tk.Frame(self, bg="#181818")
        search_frame.pack(fill="x", padx=12, pady=(8, 4))
        tk.Label(search_frame, text="🔍", bg="#181818", fg="white").pack(side="left")
        self.recherche_var = tk.StringVar()
        self.recherche_var.trace_add("write", lambda *a: self.filtrer())
        entry = tk.Entry(search_frame, textvariable=self.recherche_var, bg="#242424", fg="white",
                          insertbackground="white", relief="flat", font=("Segoe UI", 10))
        entry.pack(side="left", fill="x", expand=True, padx=8, ipady=4)

        # ----- barre de progression -----
        self.progress = ttk.Progressbar(self, style="TProgressbar", mode="determinate")
        self.progress.pack(fill="x", padx=12, pady=(0, 4))

        # ----- treeview -----
        cols = ("nom", "taille", "type", "barre")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", selectmode="browse")
        self.tree.heading("nom", text="Nom")
        self.tree.heading("taille", text="Taille")
        self.tree.heading("type", text="Type")
        self.tree.heading("barre", text="Proportion")
        self.tree.column("nom", width=340)
        self.tree.column("taille", width=100, anchor="e")
        self.tree.column("type", width=180, anchor="w")
        self.tree.column("barre", width=280)
        self.tree.pack(fill="both", expand=True, padx=12, pady=6)

        self.tree.tag_configure("critique", foreground="#ff5555")
        self.tree.tag_configure("paire", background="#282828")
        self.tree.tag_configure("impaire", background="#242424")

        self.tree.bind("<Double-1>", self.on_double_clic)
        self.tree.bind("<Button-3>", self.menu_contextuel)

        # ----- statut -----
        bas = tk.Frame(self, bg="#181818")
        bas.pack(fill="x", padx=12, pady=(0, 10))
        self.status = tk.StringVar(value="Choisis un dossier à analyser.")
        tk.Label(bas, textvariable=self.status, bg="#181818", fg="#999999",
                 anchor="w", font=("Segoe UI", 9)).pack(side="left")
        self.status_legende = tk.Label(bas, text="⚠️ = important pour Windows, à ne pas supprimer",
                                        bg="#181818", fg="#ff5555", font=("Segoe UI", 8, "italic"))
        self.status_legende.pack(side="right")

        # ----- menu clic droit -----
        self.menu = tk.Menu(self, tearoff=0, bg="#242424", fg="white",
                             activebackground="#0a84ff")
        self.menu.add_command(label="📂 Ouvrir dans l'explorateur", command=self.ouvrir_explorateur)
        self.menu.add_command(label="🗑️ Supprimer", command=self.supprimer_selection)

    # ---------- Actions ----------
    def choisir_dossier(self):
        dossier = filedialog.askdirectory()
        if dossier:
            self.historique = []
            self.scanner(dossier)

    def precedent(self):
        if self.historique:
            precedent = self.historique.pop()
            self.scanner(precedent)

    def ouvrir_chemin_actuel(self):
        chemin = self.chemin_actuel.get()
        if chemin and os.path.isdir(chemin):
            os.startfile(chemin)

    def scanner(self, chemin):
        if self.scan_en_cours or not chemin:
            return
        self.scan_en_cours = True
        self.chemin_actuel.set(chemin)
        self.status.set("⏳ Scan en cours...")
        self.progress["value"] = 0
        self.tree.delete(*self.tree.get_children())
        self.donnees = []

        def travail():
            resultats = []
            try:
                entries = list(os.scandir(chemin))
            except (PermissionError, OSError) as e:
                self.after(0, lambda: self.status.set(f"❌ Erreur d'accès : {e}"))
                self.scan_en_cours = False
                return

            total = len(entries) or 1
            for i, entry in enumerate(entries, 1):
                self.after(0, lambda i=i, n=entry.name: (
                    self.status.set(f"⏳ Scan : {i}/{total} — {n}"),
                    self.progress.configure(value=i / total * 100)
                ))
                try:
                    if entry.is_file(follow_symlinks=False):
                        taille = entry.stat().st_size
                        resultats.append((entry.name, taille, "fichier", entry.path))
                    elif entry.is_dir(follow_symlinks=False):
                        taille = taille_dossier(entry.path)
                        resultats.append((entry.name, taille, "dossier", entry.path))
                except (PermissionError, OSError):
                    continue

            resultats.sort(key=lambda x: x[1], reverse=True)
            self.donnees = resultats
            self.after(0, self.afficher, resultats)
            self.scan_en_cours = False

        threading.Thread(target=travail, daemon=True).start()

    def afficher(self, resultats):
        self.tree.delete(*self.tree.get_children())
        max_taille = resultats[0][1] if resultats else 1
        for i, (nom, taille, type_, chemin) in enumerate(resultats):
            est_dossier = type_ == "dossier"
            label_type, couleur, critique = classifier(nom, chemin, est_dossier)
            icone = "📁" if est_dossier else "📄"
            pourcentage = taille / max_taille * 100 if max_taille else 0
            barre = "█" * int(pourcentage / 3.5)
            alternance = "paire" if i % 2 == 0 else "impaire"
            tag = "critique" if critique else alternance
            prefixe = "⚠️ " if critique else ""
            self.tree.insert("", "end",
                              values=(f"{icone} {prefixe}{nom}", taille_lisible(taille), label_type, barre),
                              tags=(chemin, tag))
        total = sum(r[1] for r in resultats)
        self.status.set(f"✅ {len(resultats)} éléments — total {taille_lisible(total)}")
        self.progress.configure(value=100)

    def filtrer(self):
        terme = self.recherche_var.get().lower()
        filtres = [r for r in self.donnees if terme in r[0].lower()] if terme else self.donnees
        self.afficher(filtres)

    def on_double_clic(self, event):
        item = self.tree.selection()
        if not item:
            return
        chemin = self.tree.item(item[0], "tags")[0]
        if os.path.isdir(chemin):
            self.historique.append(self.chemin_actuel.get())
            self.scanner(chemin)

    def menu_contextuel(self, event):
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)
            self.menu.post(event.x_root, event.y_root)

    def _chemin_selection(self):
        item = self.tree.selection()
        if not item:
            return None
        return self.tree.item(item[0], "tags")[0]

    def ouvrir_explorateur(self):
        chemin = self._chemin_selection()
        if not chemin:
            return
        if os.path.isdir(chemin):
            os.startfile(chemin)
        else:
            subprocess.run(["explorer", "/select,", chemin])

    def supprimer_selection(self):
        chemin = self._chemin_selection()
        if not chemin:
            return
        nom = os.path.basename(chemin)

        if est_chemin_sensible(chemin):
            reponse = messagebox.askyesno(
                "⚠️ Attention — fichier système",
                f"'{nom}' semble être un dossier/fichier IMPORTANT pour Windows "
                f"ou un programme installé.\n\nLe supprimer peut casser ton système "
                f"ou un logiciel installé.\n\nTu es VRAIMENT sûr de vouloir continuer ?",
                icon="warning"
            )
            if not reponse:
                return
        else:
            if not messagebox.askyesno("Confirmation", f"Supprimer définitivement :\n{nom} ?"):
                return
        try:
            if os.path.isdir(chemin):
                shutil.rmtree(chemin, onerror=lambda *a: None)
            else:
                os.remove(chemin)
        except (PermissionError, OSError):
            # Pas les droits sur certains fichiers -> on skip silencieusement,
            # ce qui a pu être supprimé l'est déjà.
            pass
        self.scanner(self.chemin_actuel.get())


if __name__ == "__main__":
    app = App()
    if len(sys.argv) > 1 and os.path.isdir(sys.argv[1]):
        app.scanner(sys.argv[1])
    app.mainloop()