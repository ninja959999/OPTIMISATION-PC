@echo off
title Explorateur Disque
cd /d "%~dp0"
python explorateur_disque_v2.py
